---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
tags : ["Dev", "Go"]
categories : ["Dev", "Go"]
draft: true
---
